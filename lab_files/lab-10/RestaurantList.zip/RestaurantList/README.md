# webage-bah-gradle

Gradle application supports a RESTful GET operation
to return a list of restaurants

Execute in root directory with: _gradle bootRun_

By default listens to port: 9001

http://_hostname_:9001/restaurants




